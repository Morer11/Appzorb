import React from 'react';
import { Link } from 'react-router-dom';
import { PackageOpen, Smartphone, Download, ChevronRight } from 'lucide-react';
import FeatureCard from '../components/FeatureCard';

const Home: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <section className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
          Convert Your Web Games to Android Apps offline
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
          Upload your HTML5 game files and get a ready-to-publish Android APK in minutes.
          No coding required!
        </p>
        <Link
          to="/upload"
          className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg 
                    shadow-lg hover:bg-indigo-700 transition-colors duration-300"
        >
          Start Converting <ChevronRight className="ml-2 h-5 w-5" />
        </Link>
      </section>

      <section className="grid md:grid-cols-3 gap-8 mb-16">
        <FeatureCard 
          icon={<PackageOpen className="h-12 w-12 text-indigo-500" />}
          title="Upload Your Game"
          description="Package your HTML, CSS, and JavaScript files into a ZIP archive and upload it to our platform."
        />
        <FeatureCard 
          icon={<Smartphone className="h-12 w-12 text-indigo-500" />}
          title="Automatic Conversion"
          description="Our system automatically converts your web game to a native Android application using Capacitor."
        />
        <FeatureCard 
          icon={<Download className="h-12 w-12 text-indigo-500" />}
          title="Download & Publish"
          description="Download your APK file and publish it to the Google Play Store or distribute it directly."
        />
      </section>

      <section className="bg-gray-100 rounded-xl p-8 mb-16">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">How It Works</h2>
        <ol className="list-decimal pl-5 space-y-4">
          <li className="text-gray-700">
            <span className="font-medium">Prepare your game:</span> Ensure your game works in a web browser and package all necessary files (HTML, CSS, JS, assets) into a ZIP file.
          </li>
          <li className="text-gray-700">
            <span className="font-medium">Upload:</span> Drag and drop your ZIP file on our upload page.
          </li>
          <li className="text-gray-700">
            <span className="font-medium">Wait for conversion:</span> Our system will process your game and create an Android APK.
          </li>
          <li className="text-gray-700">
            <span className="font-medium">Download:</span> Once the process is complete, download your APK file.
          </li>
        </ol>
      </section>

      <section className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Ready to Convert Your Game?</h2>
        <Link
          to="/upload"
          className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg 
                    shadow-lg hover:bg-indigo-700 transition-colors duration-300 mt-4"
        >
          Get Started Now <ChevronRight className="ml-2 h-5 w-5" />
        </Link>
      </section>
    </div>
  );
};

export default Home;
