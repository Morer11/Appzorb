# Game to APK Converter

A web application that allows users to convert HTML5 games to Android APK files.

## Features

- Upload ZIP files containing HTML5 game files
- Automatic conversion to Android APK using Capacitor
- Real-time build progress tracking
- Downloadable APK files
- Responsive design that works on all devices

## Tech Stack

### Frontend
- React
- TypeScript
- Tailwind CSS
- React Router
- React Dropzone
- Socket.io (for real-time status updates)

### Backend
- Node.js
- Express
- Capacitor (for APK generation)

## Getting Started

### Prerequisites

- Node.js v18 or higher
- npm or yarn
- For actual APK building: Android SDK and JDK

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/game-to-apk-converter.git
cd game-to-apk-converter
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. In a separate terminal, start the backend server:
```bash
npm run server
```

## Usage

1. Access the application at `http://localhost:5173` (or whatever port Vite is using)
2. Upload a ZIP file containing your HTML5 game
3. Wait for the conversion process to complete
4. Download the generated APK file

## Build Requirements

For a production server that can build real APK files, you'll need:

- Android SDK installed
- JDK 11 or higher
- Gradle
- Environment variables set up for Android development

## Deployment

### Frontend Deployment

1. Build the frontend:
```bash
npm run build
```

2. Deploy the contents of the `dist` directory to your web server

### Backend Deployment

1. Set up a server with Node.js and the Android SDK
2. Clone the repository and install dependencies
3. Configure environment variables
4. Start the server with a process manager like PM2:
```bash
pm2 start server/index.js
```

## Project Structure

```
/
├── src/                  # Frontend React code
│   ├── components/       # Reusable UI components
│   ├── pages/            # Page components
│   ├── services/         # API services
│   ├── types/            # TypeScript type definitions
│   └── App.tsx           # Main application component
├── server/               # Backend server code
│   ├── uploads/          # Temporary storage for uploaded files
│   ├── builds/           # Storage for generated APK files
│   └── index.js          # Express server
└── public/               # Static assets
```

## Limitations

This demo version simulates the APK building process. For a full implementation:

1. You need a server with Android SDK installed
2. The APK building process requires significant resources
3. Large files may take a while to process

## License

MIT